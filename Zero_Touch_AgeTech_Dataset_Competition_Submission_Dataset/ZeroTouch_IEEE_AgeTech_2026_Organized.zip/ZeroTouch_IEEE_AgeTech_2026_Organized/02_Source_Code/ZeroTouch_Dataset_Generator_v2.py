# Exported from ZeroTouch_Dataset_Generator_v2.ipynb (version 2.0.0).
# Synthetic data only. Do not interpret as measured or clinically validated data.
# Run: python ZeroTouch_Dataset_Generator_v2.py

# ---- Original notebook code cell 2 ----
import hashlib, json, platform
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "2.0.0"

# ---- Original notebook code cell 4 ----
@dataclass(frozen=True)
class Config:
    seed: int = 42
    n_rows: int = 20_000
    n_participants: int = 160
    n_days: int = 30
    start_date: str = "2026-01-01"
    ambiguity_rate: float = 0.10   # share of events whose movement blends with a confusable class
    occlusion_rate: float = 0.03   # share of events with a partly blocked sensor
    audit_threshold: float = 0.40  # a single feature may not classify better than this (balanced acc.)


SETTINGS = {"aging_in_place_room": "home", "assisted_living_room": "home", "hospital_ward": "hospital"}
SETTING_PROBS = [0.30, 0.35, 0.35]
MOBILITY = ["independent", "limited", "assisted"]
AGE_BANDS = ["60-64", "65-69", "70-74", "75-79", "80-84", "85-89", "90+"]

# ---- Original notebook code cell 6 ----
PARAM_NAMES = ["ld", "sd_d", "lv", "sd_v", "lt", "sd_t", "ltr", "sd_tr",
               "dw_a", "dw_b", "cyc", "hand", "vt_mu", "vt_sd", "ang_mu", "ang_sd"]
K = {name: i for i, name in enumerate(PARAM_NAMES)}


def behaviour(dist, vel, dur, tremor, dwell, cycles, hand, vtravel, angle):
    """(median, sigma) pairs are lognormal; dwell is a Beta share of duration."""
    return np.array([np.log(dist[0]), dist[1], np.log(vel[0]), vel[1], np.log(dur[0]), dur[1],
                     np.log(tremor[0]), tremor[1], dwell[0], dwell[1], cycles, hand,
                     vtravel[0], vtravel[1], angle[0], angle[1]], dtype=float)


#                              distance cm   speed m/s    duration ms   tremor      dwell   cyc  hand  vert-travel  angle
BEHAVIOUR = {
    "intentional_light_on":      behaviour((14, .30), (.30, .35), (900, .35),  (.12, .5), (6, 3), 1.3, .96, (3, 3.5),  (0, 25)),
    "intentional_light_off":     behaviour((14, .30), (.30, .35), (900, .35),  (.12, .5), (6, 3), 1.3, .96, (-3, 3.5), (0, 25)),
    "intentional_fan_on":        behaviour((18, .30), (.28, .35), (1000, .35), (.12, .5), (6, 3), 1.3, .96, (3, 3.5),  (10, 30)),
    "intentional_fan_off":       behaviour((18, .30), (.28, .35), (1000, .35), (.12, .5), (6, 3), 1.3, .96, (-3, 3.5), (10, 30)),
    "intentional_tap_on":        behaviour((10, .30), (.25, .35), (800, .35),  (.12, .5), (6, 3), 1.2, .96, (0, 2.5),  (-40, 25)),
    "intentional_toilet_flush":  behaviour((12, .30), (.45, .35), (600, .35),  (.12, .5), (5, 3), 1.4, .95, (0, 3),    (35, 25)),
    "intentional_bed_raise":     behaviour((20, .30), (.20, .35), (1400, .35), (.12, .5), (7, 3), 1.2, .96, (6, 3.5),  (0, 25)),
    "intentional_bed_lower":     behaviour((20, .30), (.20, .35), (1400, .35), (.12, .5), (7, 3), 1.2, .96, (-6, 3.5), (0, 25)),
    "emergency_help":            behaviour((20, .35), (.60, .40), (3200, .35), (.16, .5), (5, 3), 5.0, .90, (0, 8),    (0, 40)),
    "unintentional_passing":     behaviour((55, .45), (.90, .35), (500, .50),  (.08, .6), (2, 5), 0.6, .30, (0, 10),   (0, 60)),
    "unintentional_staff_activity": behaviour((35, .45), (.70, .40), (1200, .50), (.08, .6), (3, 4), 1.5, .55, (0, 7), (0, 50)),
    "background_no_activity":    behaviour((90, .50), (.05, .80), (200, .60),  (.04, .7), (2, 4), 0.0, .03, (0, 1.5),  (0, 90)),
}
CLASSES = list(BEHAVIOUR)
PARAMS = np.stack([BEHAVIOUR[c] for c in CLASSES])

# "Hard cases": an ambiguous event blends its own movement profile with this look-alike class.
CONFUSER = {c: "unintentional_staff_activity" for c in CLASSES if c.startswith("intentional_")}
CONFUSER.update({"emergency_help": "unintentional_staff_activity",
                 "unintentional_passing": "unintentional_staff_activity",
                 "unintentional_staff_activity": "intentional_light_on",
                 "background_no_activity": "unintentional_passing"})

# Class mix depends on environment (beds exist only on the ward; staff are more frequent there).
CLASS_PRIORS = {
    "home": dict(intentional_light_on=.13, intentional_light_off=.10, intentional_fan_on=.07,
                 intentional_fan_off=.05, intentional_tap_on=.10, intentional_toilet_flush=.08,
                 intentional_bed_raise=0, intentional_bed_lower=0, emergency_help=.02,
                 unintentional_passing=.17, unintentional_staff_activity=.04, background_no_activity=.24),
    "hospital": dict(intentional_light_on=.09, intentional_light_off=.07, intentional_fan_on=.04,
                     intentional_fan_off=.03, intentional_tap_on=.06, intentional_toilet_flush=.05,
                     intentional_bed_raise=.06, intentional_bed_lower=.05, emergency_help=.03,
                     unintentional_passing=.12, unintentional_staff_activity=.17, background_no_activity=.23),
}
for _env, _p in CLASS_PRIORS.items():
    assert set(_p) == set(CLASSES) and abs(sum(_p.values()) - 1) < 1e-9, _env

# Shape of the day, per class (probability of each hour).
def _bumps(centers, width=1.5, base=0.15):
    h = np.arange(24)
    w = base + sum((np.exp(-0.5 * (np.minimum(abs(h - c), 24 - abs(h - c)) / width) ** 2) for c in centers), np.zeros(24))
    return w / w.sum()


HOURS = {"waking": _bumps([7.5, 12.5, 19]), "dark": _bumps([6, 18.5, 21.5], base=.1),
         "bed_wake": _bumps([7, 22.5]), "afternoon": _bumps([11, 14.5, 17]),
         "night": _bumps([2, 4, 21], base=.25), "rounds": _bumps([8, 12, 16, 20], 1.0, .1),
         "waking_night": _bumps([3, 7, 22]), "flat": _bumps([], base=1.0)}
HOUR_PROFILE = {"intentional_light_on": "dark", "intentional_light_off": "bed_wake",
                "intentional_fan_on": "afternoon", "intentional_fan_off": "afternoon",
                "intentional_tap_on": "waking", "intentional_toilet_flush": "waking_night",
                "intentional_bed_raise": "rounds", "intentional_bed_lower": "rounds",
                "emergency_help": "night", "unintentional_passing": "waking",
                "unintentional_staff_activity": "rounds", "background_no_activity": "flat"}

# Mobility changes how people move: (distance, speed, duration, tremor) multipliers.
MOBILITY_EFFECT = np.array([[1.00, 1.00, 1.00, 1.0], [1.05, 0.85, 1.20, 1.5], [1.15, 0.70, 1.45, 2.0]])

# Illustrative sensor behaviour (NOT calibrated to datasheets): valid range, noise, light sensitivity.
SENSORS = {"ultrasonic":       dict(rng=(2, 200), abs=0.60, rel=0.02, light=0.0, p=0.40),
           "time_of_flight":   dict(rng=(4, 130), abs=0.25, rel=0.01, light=1.0, p=0.30),
           "infrared_ranging": dict(rng=(5, 80),  abs=1.00, rel=0.04, light=1.0, p=0.30)}

# Correlation between log-distance, log-speed, log-duration, log-tremor within an event.
_R = np.array([[1, -.20, .15, .10], [-.20, 1, -.45, .25], [.15, -.45, 1, -.10], [.10, .25, -.10, 1]])
_CHOL = np.linalg.cholesky(_R)  # raises if the matrix is not positive-definite

# ---- Original notebook code cell 8 ----
@dataclass(frozen=True)
class Col:
    name: str
    role: str          # id | participant | context | sensor | metadata | target
    dtype: str
    unit: str
    description: str
    lo: float | None = None
    hi: float | None = None
    allowed: tuple | None = None


SPEC = [
    Col("event_id", "id", "str", "", "Chronological event identifier"),
    Col("timestamp", "id", "datetime", "UTC", "Simulated event time (no real clock)"),
    Col("participant_id", "id", "str", "", "Synthetic participant; use as the grouping key when splitting"),
    Col("age", "participant", "int", "years", "Participant age (fixed per participant)", 60, 100),
    Col("age_band", "metadata", "cat", "", "Age band, for subgroup analysis only", allowed=tuple(AGE_BANDS)),
    Col("mobility_profile", "participant", "cat", "", "Mobility level; depends on age and setting", allowed=tuple(MOBILITY)),
    Col("environment", "context", "cat", "", "home or hospital", allowed=("home", "hospital")),
    Col("setting", "context", "cat", "", "Room type (fixed per participant)", allowed=tuple(SETTINGS)),
    Col("sensor_modality", "context", "cat", "", "Sensor installed in the room (fixed per participant)", allowed=tuple(SENSORS)),
    Col("hour_of_day", "context", "int", "hour", "Hour of the simulated event", 0, 23),
    Col("ambient_light_lux", "context", "float", "lux", "Ambient light; follows a daylight curve", 1, 2000),
    Col("distance_cm", "sensor", "float", "cm", "Hand/body distance as the sensor reports it; empty when outside sensor range or occluded", 2, 200),
    Col("vertical_travel_cm", "sensor", "float", "cm", "Net vertical hand movement (positive = up)", -60, 60),
    Col("approach_angle_deg", "sensor", "float", "deg", "Approach angle relative to the sensor axis", -180, 180),
    Col("velocity_m_s", "sensor", "float", "m/s", "Peak movement speed", 0, 4),
    Col("duration_ms", "sensor", "int", "ms", "Total event duration", 10, 20000),
    Col("dwell_ms", "sensor", "int", "ms", "Time spent in the sensing zone (never exceeds duration)", 1, 20000),
    Col("motion_cycles", "sensor", "int", "count", "Number of movement cycles (waves, swipes)", 0, 30),
    Col("tremor_index", "sensor", "float", "0-1", "Hand-motion variability", 0, 1),
    Col("hand_detected", "sensor", "bool", "", "Whether a hand-like object was detected"),
    Col("occlusion_flag", "sensor", "bool", "", "Sensor partly blocked during the event"),
    Col("signal_quality", "sensor", "float", "0-1", "Signal quality; low quality means noisier readings", 0, 1),
    Col("is_ambiguous", "metadata", "bool", "", "Generated from a blended, look-alike profile (hard case)"),
    Col("y_activity", "target", "cat", "", "12-class activity label", allowed=tuple(CLASSES)),
    Col("y_is_intentional", "target", "bool", "", "Deliberate device command (derived from y_activity)"),
    Col("y_is_emergency", "target", "bool", "", "Emergency-help gesture (derived from y_activity)"),
]
FEATURES = [c.name for c in SPEC if c.role in {"participant", "context", "sensor"}]
GROUP = "participant_id"
TARGET = "y_activity"

# ---- Original notebook code cell 10 ----
def truncated_normal(rng, mu, sd, lo, hi, size):
    x = rng.normal(mu, sd, size)
    bad = (x < lo) | (x > hi)
    while bad.any():
        x[bad] = rng.normal(mu, sd, bad.sum())
        bad = (x < lo) | (x > hi)
    return x


def make_participants(cfg: Config, rng) -> pd.DataFrame:
    n = cfg.n_participants
    age = np.round(truncated_normal(rng, 77, 9, 60, 100, n)).astype(int)
    setting = rng.choice(list(SETTINGS), n, p=SETTING_PROBS)
    ward = setting == "hospital_ward"
    # Mobility worsens with age, and more so on the ward (multinomial logit).
    logits = np.column_stack([np.zeros(n),
                              -1.8 + 0.07 * (age - 60) + 0.5 * ward,
                              -3.2 + 0.09 * (age - 60) + 1.0 * ward])
    p = np.exp(logits) / np.exp(logits).sum(axis=1, keepdims=True)
    mobility = np.array(MOBILITY)[(rng.random(n)[:, None] > p.cumsum(axis=1)).sum(axis=1)]
    return pd.DataFrame({
        "participant_id": [f"OA{i:03d}" for i in range(1, n + 1)],
        "age": age, "mobility_profile": mobility, "setting": setting,
        "environment": [SETTINGS[s] for s in setting],
        "sensor_modality": rng.choice(list(SENSORS), n, p=[v["p"] for v in SENSORS.values()]),
        # Person-level traits: repeated events from one person are correlated.
        "speed_factor": rng.lognormal(0, 0.20, n),
        "tremor_factor": rng.lognormal(0, 0.35, n),
        "reach_factor": rng.lognormal(0, 0.15, n),
    })


def generate(cfg: Config) -> pd.DataFrame:
    # Independent random streams: changing n_rows never changes the participants.
    r_people, r_events, r_meas = (np.random.default_rng(s) for s in np.random.SeedSequence(cfg.seed).spawn(3))
    people = make_participants(cfg, r_people)

    # --- who does what, where, when ------------------------------------------------
    weights = r_events.gamma(4.0, 1.0, cfg.n_participants)           # uneven participation
    counts = r_events.multinomial(cfg.n_rows, weights / weights.sum())
    ev = people.loc[np.repeat(np.arange(cfg.n_participants), counts)].reset_index(drop=True)
    n = len(ev)

    cls = np.empty(n, dtype=object)
    for env, prior in CLASS_PRIORS.items():
        m = (ev["environment"] == env).to_numpy()
        cls[m] = r_events.choice(CLASSES, m.sum(), p=[prior[c] for c in CLASSES])
    hour = np.empty(n, dtype=int)
    for c in CLASSES:
        m = cls == c
        hour[m] = r_events.choice(24, m.sum(), p=HOURS[HOUR_PROFILE[c]])
    seconds = r_events.integers(0, cfg.n_days, n) * 86400 + hour * 3600 + r_events.integers(0, 3600, n)
    timestamp = np.datetime64(cfg.start_date, "s") + seconds.astype("timedelta64[s]")

    # --- movement profile, with hard cases ----------------------------------------
    own = PARAMS[pd.Index(CLASSES).get_indexer(cls)]
    twin = PARAMS[pd.Index(CLASSES).get_indexer([CONFUSER[c] for c in cls])]
    ambiguous = r_events.random(n) < cfg.ambiguity_rate
    lam = np.where(ambiguous, r_events.uniform(0.3, 0.7, n), 0.0)[:, None]
    P = (1 - lam) * own + lam * twin

    # --- context -------------------------------------------------------------------
    daylight = 450 * np.clip(np.sin(np.pi * (hour + 0.5 - 6) / 12), 0, None) ** 1.5
    window = np.where(ev["environment"] == "hospital", 0.5, 1.0)
    lux = np.clip((25 + daylight * window) * r_meas.lognormal(0, 0.45, n), 1, 2000)
    occluded = r_meas.random(n) < cfg.occlusion_rate
    quality = np.clip(r_meas.beta(12, 1.6, n) - occluded * r_meas.uniform(0.2, 0.5, n), 0, 1)
    noise_scale = 1 + 1.5 * (1 - quality)                              # poor signal -> noisier

    # --- true movement ---------------------------------------------------------------
    Z = r_meas.standard_normal((n, 4)) @ _CHOL.T
    mob = MOBILITY_EFFECT[pd.Index(MOBILITY).get_indexer(ev["mobility_profile"])]
    dist = np.exp(P[:, K["ld"]] + P[:, K["sd_d"]] * Z[:, 0]) * ev["reach_factor"].to_numpy() * mob[:, 0]
    vel = np.exp(P[:, K["lv"]] + P[:, K["sd_v"]] * Z[:, 1]) * ev["speed_factor"].to_numpy() * mob[:, 1]
    dur = np.exp(P[:, K["lt"]] + P[:, K["sd_t"]] * Z[:, 2]) * mob[:, 2]
    trem = np.exp(P[:, K["ltr"]] + P[:, K["sd_tr"]] * Z[:, 3]) * ev["tremor_factor"].to_numpy() * mob[:, 3]
    cycles = np.where(cls == "background_no_activity", 0, 1 + r_meas.poisson(np.clip(P[:, K["cyc"]], 0, None)))
    vtravel = r_meas.normal(P[:, K["vt_mu"]], P[:, K["vt_sd"]])
    angle = (r_meas.normal(P[:, K["ang_mu"]], P[:, K["ang_sd"]]) + 180) % 360 - 180
    hand = r_meas.random(n) < np.clip(P[:, K["hand"]], 0, 1) * (0.7 + 0.3 * quality)

    # --- what the sensor reports -----------------------------------------------------
    spec = [SENSORS[s] for s in ev["sensor_modality"]]
    lo = np.array([s["rng"][0] for s in spec]); hi = np.array([s["rng"][1] for s in spec])
    sd = (np.array([s["abs"] for s in spec]) + np.array([s["rel"] for s in spec]) * dist) * noise_scale
    sd = sd * (1 + np.array([s["light"] for s in spec]) * lux / 800) * np.where(occluded, 2.0, 1.0)
    dist_obs = dist + r_meas.normal(0, 1, n) * sd
    invalid = (dist_obs < lo) | (dist_obs > hi) | (occluded & (r_meas.random(n) < 0.3))
    dist_obs = np.where(invalid, np.nan, dist_obs)
    vel_obs = vel * np.exp(r_meas.normal(0, 0.05 * noise_scale))
    dur_i = np.maximum(10, np.round(dur * np.exp(r_meas.normal(0, 0.05 * noise_scale)))).astype(int)
    dwell_i = np.clip(np.floor(dur_i * r_meas.beta(P[:, K["dw_a"]], P[:, K["dw_b"]])), 1, dur_i).astype(int)

    age = ev["age"].to_numpy()
    band = np.select([age < 65, age < 70, age < 75, age < 80, age < 85, age < 90], AGE_BANDS[:6], AGE_BANDS[6])
    df = pd.DataFrame({
        "timestamp": timestamp, "participant_id": ev["participant_id"], "age": age, "age_band": band,
        "mobility_profile": ev["mobility_profile"], "environment": ev["environment"],
        "setting": ev["setting"], "sensor_modality": ev["sensor_modality"], "hour_of_day": hour,
        "ambient_light_lux": lux.round(1), "distance_cm": np.round(dist_obs, 1),
        "vertical_travel_cm": vtravel.round(1), "approach_angle_deg": angle.round(1),
        "velocity_m_s": np.minimum(vel_obs, 4.0).round(3), "duration_ms": dur_i, "dwell_ms": dwell_i,
        "motion_cycles": cycles, "tremor_index": np.clip(trem, 0, 1).round(3), "hand_detected": hand,
        "occlusion_flag": occluded, "signal_quality": quality.round(3), "is_ambiguous": ambiguous,
        "y_activity": cls,
    })
    df = df.sort_values("timestamp", kind="stable").reset_index(drop=True)
    df.insert(0, "event_id", [f"ZT{i:06d}" for i in range(1, n + 1)])
    df["y_is_intentional"] = df["y_activity"].str.startswith("intentional_")
    df["y_is_emergency"] = df["y_activity"].eq("emergency_help")
    return df[[c.name for c in SPEC]]

# ---- Original notebook code cell 12 ----
def validate(df: pd.DataFrame, cfg: Config) -> list[dict]:
    results = []

    def check(name, ok, detail=""):
        results.append({"check": name, "passed": bool(ok), "detail": str(detail)})

    check("columns match schema, in order", list(df.columns) == [c.name for c in SPEC])
    check("row count", len(df) == cfg.n_rows, len(df))
    check("event_id unique", df["event_id"].is_unique)
    check("timestamps non-decreasing", df["timestamp"].is_monotonic_increasing)
    check("no duplicate events", not df.drop(columns="event_id").duplicated().any())
    check("no constant columns", all(df[c].nunique(dropna=True) > 1 for c in df.columns))

    for c in SPEC:
        s = df[c.name]
        if c.lo is not None:
            ok = s.dropna().between(c.lo, c.hi).all()
            check(f"{c.name} within [{c.lo}, {c.hi}]", ok)
            if c.dtype == "float":  # clipping artefacts only matter for continuous columns
                at_edge = s.isin([c.lo, c.hi]).mean()
                check(f"{c.name} not piled up at its bounds", at_edge < 0.005, f"{at_edge:.4%}")
        if c.allowed:
            check(f"{c.name} only allowed values", s.isin(c.allowed).all())

    miss = df.isna().mean()
    check("missing values only in distance_cm", set(miss[miss > 0].index) <= {"distance_cm"})
    check("distance_cm missing rate < 10%", miss["distance_cm"] < 0.10, f"{miss['distance_cm']:.2%}")
    check("dwell_ms <= duration_ms", (df["dwell_ms"] <= df["duration_ms"]).all())
    check("bed events only on hospital ward",
          df.loc[df["y_activity"].str.contains("bed"), "environment"].eq("hospital").all())
    check("participant traits constant per participant",
          df.groupby(GROUP)[["age", "mobility_profile", "setting", "sensor_modality"]].nunique().max().max() == 1)
    check("environment consistent with setting", (df["setting"].map(SETTINGS) == df["environment"]).all())
    check("all 12 classes present, none < 100 rows", df[TARGET].value_counts().reindex(CLASSES).fillna(0).min() >= 100,
          df[TARGET].value_counts().min())
    expected_em = sum(CLASS_PRIORS[e]["emergency_help"] * (df["environment"] == e).mean() for e in CLASS_PRIORS)
    check("emergency prevalence near configured prior", abs(df["y_is_emergency"].mean() - expected_em) < 0.01,
          f"{df['y_is_emergency'].mean():.3%} vs {expected_em:.3%}")
    return results


def _numeric_matrix(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    X = df[cols].copy()
    for c in cols:
        if pd.api.types.is_bool_dtype(X[c]):
            X[c] = X[c].astype(int)
        elif not pd.api.types.is_numeric_dtype(X[c]):
            X[c] = pd.factorize(X[c])[0]
    return X


def leakage_audit(df: pd.DataFrame, cfg: Config) -> list[dict]:
    """No single feature may carry the label on its own."""
    from sklearn.model_selection import GroupKFold, cross_val_score
    from sklearn.tree import DecisionTreeClassifier
    X = _numeric_matrix(df, FEATURES)
    out = []
    for f in FEATURES:
        score = cross_val_score(DecisionTreeClassifier(max_depth=4, random_state=0), X[[f]], df[TARGET],
                                groups=df[GROUP], cv=GroupKFold(3), scoring="balanced_accuracy").mean()
        out.append({"check": f"single-feature audit: {f}", "passed": score < cfg.audit_threshold,
                    "detail": f"balanced accuracy {score:.3f}"})
    return out


def baseline(df: pd.DataFrame) -> dict:
    """Reference result: grouped 5-fold CV, so no participant appears in train and test."""
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import average_precision_score, f1_score, precision_score, recall_score
    from sklearn.model_selection import GroupKFold, cross_val_predict
    X = _numeric_matrix(df, FEATURES)
    y = df[TARGET]
    model = HistGradientBoostingClassifier(max_iter=150, random_state=0)
    proba = cross_val_predict(model, X, y, groups=df[GROUP], cv=GroupKFold(5), method="predict_proba")
    classes = np.array(sorted(y.unique()))
    pred = classes[proba.argmax(axis=1)]
    amb = df["is_ambiguous"].to_numpy()
    em = classes.tolist().index("emergency_help")

    def coarse(a):  # 3-way task: deliberate command / emergency / not a command
        return np.where(a == "emergency_help", "emergency", np.where(pd.Series(a).str.startswith("intentional_"), "command", "ignore"))
    c_true, c_pred = coarse(y.to_numpy()), coarse(pred)
    return {
        "macro_f1": round(f1_score(y, pred, average="macro"), 3),
        "accuracy": round(float((pred == y).mean()), 3),
        "macro_f1_clear_cases": round(f1_score(y[~amb], pred[~amb], average="macro"), 3),
        "macro_f1_ambiguous_cases": round(f1_score(y[amb], pred[amb], average="macro"), 3),
        "three_way_macro_f1_command_emergency_ignore": round(f1_score(c_true, c_pred, average="macro"), 3),
        "emergency_precision": round(precision_score(y == "emergency_help", pred == "emergency_help"), 3),
        "emergency_recall": round(recall_score(y == "emergency_help", pred == "emergency_help"), 3),
        "emergency_pr_auc": round(average_precision_score(y == "emergency_help", proba[:, em]), 3),
        "per_class_recall": dict(zip(classes, recall_score(y, pred, average=None, labels=classes).round(3))),
    }

# ---- Original notebook code cell 14 ----
def write_release(df, cfg, results, out: Path, base=None):
    out.mkdir(parents=True, exist_ok=True)
    csv_bytes = df.to_csv(index=False).encode()
    (out / "zerotouch_v2.csv").write_bytes(csv_bytes)
    pd.DataFrame([asdict(c) for c in SPEC]).to_csv(out / "data_dictionary.csv", index=False)
    (out / "schema.json").write_text(json.dumps(
        {"features": FEATURES, "target": TARGET, "group": GROUP,
         "never_use_as_features": [c.name for c in SPEC if c.role in {"id", "metadata", "target"}]}, indent=2))
    manifest = {"generator_version": VERSION, "config": asdict(cfg), "rows": len(df), "columns": len(df.columns),
                "sha256": hashlib.sha256(csv_bytes).hexdigest(),
                "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
                "data_origin": "SYNTHETIC - no real participants or sensor recordings",
                "checks_passed": sum(r["passed"] for r in results), "checks_total": len(results), "baseline": base}
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    (out / "class_counts.csv").write_text(df[TARGET].value_counts().rename("count").to_csv())

if __name__ == "__main__":
    cfg = Config()
    df = generate(cfg)
    results = validate(df, cfg) + leakage_audit(df, cfg)
    results.append({"check": "same seed reproduces identical file",
                    "passed": generate(cfg).to_csv(index=False) == df.to_csv(index=False), "detail": ""})
    report = pd.DataFrame(results)
    if not report["passed"].all():
        raise RuntimeError(report.loc[~report["passed"]].to_string(index=False))
    base = baseline(df)
    out = Path("release")
    write_release(df, cfg, results, out, base)
    print(f"Created {len(df):,} rows x {df.shape[1]} columns in {out.resolve()}")
    print(f"Participants: {df['participant_id'].nunique():,}; activity classes: {df['y_activity'].nunique()}")
    print(f"Validation: {report['passed'].sum()}/{len(report)} checks passed")
