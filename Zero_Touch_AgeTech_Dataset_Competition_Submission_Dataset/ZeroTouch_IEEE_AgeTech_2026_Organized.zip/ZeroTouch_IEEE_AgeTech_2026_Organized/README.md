# Zero-Touch IEEE AgeTech 2026 — Organized Submission Package

This package organizes the **11 files uploaded for Version 2.0.0**, with names normalized by removing the upload `(1)` suffix. Original file contents have not been edited.

## Folder guide

- **01_Dataset/** — primary CSV of synthetic event records.
- **02_Source_Code/** — supplied `.py` generator and a derived Jupyter `.ipynb` conversion.
- **03_Metadata/** — release metadata, schema, data dictionary and class counts.
- **04_Documentation/** — generation protocol, ethics/governance statement and blank independent expert verification form.
- **05_Benchmark/** — supplied baseline results.
- **06_Licensing/** — supplied CC BY 4.0 notice.

## Important distinctions

1. The **`.ipynb` notebook was reconstructed from the uploaded `.py` export** for convenience. It is **not** the original notebook named in `ZeroTouch_Metadata.json`, and its SHA-256 hash should not be expected to match the original notebook hash there.
2. The metadata and generation protocol refer to an **Excel workbook** (`ZeroTouch_Dataset_Generator_v2_output.xlsx`) and an original `.ipynb` notebook. Those two originals **were not among the 11 uploaded files**, so they have not been represented as included.
3. The **Independent Expert Verification Form is blank**. Do not claim expert verification before an independent reviewer completes and signs it.
4. The governance PDF describes **CC BY 4.0 as proposed/pending confirmation**, whereas the licensing notice says selected. The dataset rights holder should formally confirm the final licence and attribution before submission.
5. The supplied baseline is an existing synthetic benchmark, not evidence of clinical or hardware validity.
6. A **competition report** compliant with the handbook requirements was not included among these 11 files. Add it separately before final submission.

## Running the code

Open `02_Source_Code/ZeroTouch_Dataset_Generator_v2_CONVERTED.ipynb` in Colab or Jupyter and run all cells, or run the Python script in a suitable local environment. Install required dependencies (NumPy, pandas, scikit-learn). Both are code supplements; **the authoritative competition dataset is `01_Dataset/ZeroTouch_Dataset_file.csv`.**

## Integrity checking

See `PACKAGE_INTEGRITY.json` for checks based on the uploaded CSV and schema. A hash manifest for every packaged file is provided in `FILE_MANIFEST_SHA256.csv`.

## Submission note

Upload dataset and report to IEEE DataPort in the portal-supported arrangement. If the portal restricts source-code formats, include the supplementary code in an accepted archive or linked source repository, following the portal's current instructions.
